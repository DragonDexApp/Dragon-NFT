export enum Network {
    Ethereum = "eth",
    Xdai = "xdai",
}
