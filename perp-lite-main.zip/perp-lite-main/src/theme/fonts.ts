const fonts = {
    heading: "system-ui, sans-serif",
    subHeading: "system-ui, sans-serif",
    body: "system-ui, sans-serif",
    mono: "Menlo, monospace",
}

export default fonts
